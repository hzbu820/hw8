package com.example.hw8q1.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.hw8q1.data.database.TaskDatabase
import com.example.hw8q1.data.entity.Task
import com.example.hw8q1.repository.TaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TaskViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TaskRepository
    
    val allTasks: StateFlow<List<Task>>
    val pendingTasks: StateFlow<List<Task>>
    val completedTasks: StateFlow<List<Task>>
    
    private val _filterType = MutableStateFlow(FilterType.ALL)
    val filterType: StateFlow<FilterType> = _filterType

    val filteredTasks: StateFlow<List<Task>>

    enum class FilterType {
        ALL,
        PENDING,
        COMPLETED
    }
    
    init {
        val taskDao = TaskDatabase.getDatabase(application).taskDao()
        repository = TaskRepository(taskDao)
        
        allTasks = repository.allTasks.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
        
        pendingTasks = repository.pendingTasks.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
        
        completedTasks = repository.completedTasks.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
        
        filteredTasks = combine(
            repository.allTasks,
            repository.pendingTasks,
            repository.completedTasks,
            _filterType
        ) { all, pending, completed, filter ->
            when (filter) {
                FilterType.ALL -> all
                FilterType.PENDING -> pending
                FilterType.COMPLETED -> completed
            }
        }.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    }
    
    fun setFilterType(filterType: FilterType) {
        _filterType.value = filterType
    }
    
    fun insertTask(title: String) {
        viewModelScope.launch {
            val task = Task(title = title)
            repository.insertTask(task)
        }
    }
    
    fun updateTask(task: Task) {
        viewModelScope.launch {
            repository.updateTask(task)
        }
    }
    
    fun deleteTask(task: Task) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }
    
    fun toggleTaskStatus(task: Task) {
        viewModelScope.launch {
            repository.toggleTaskStatus(task)
        }
    }
} 